﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitaireStat
{
    class Program
    {
        static private Deck deck;

        static private PlaySet[] playArea = new PlaySet[7];

        static private Pile[] piles = new Pile[4];

        static void Main(string[] args)
        {
            string input = string.Empty;

            deck = new Deck();
            SetupPlayCards();

            while (string.IsNullOrEmpty(input) || input.First() != 'q')
            {
                DisplayState();

                HasWon();

                input = Console.ReadLine();

                switch (input.First())
                {
                    case 'm':
                        string[] moves = input.Substring(1).Split(',');
                        int slot1, slot2;

                        bool s1 = int.TryParse(moves[0], out slot1);
                        bool s2 = int.TryParse(moves[1], out slot2);

                        if (s1 && s2)
                        {
                            if(CanMove(slot1, slot2))
                            {
                                if (slot1 > -1)
                                {
                                    MoveCards(slot1, slot2);
                                }
                                else
                                {
                                    MoveDeckCard(slot2);
                                }
                            }
                            else
                            {
                                System.Console.WriteLine("Can't make that move!\n");
                            }
                        }

                        break;
                    case 'p':
                        string pile = input.Substring(1);
                        int slot;
                        bool s = int.TryParse(pile, out slot);

                        if (s)
                        {
                            if(!CheckIfCanMoveToPile(slot))
                            {
                                System.Console.WriteLine("Can't add that to any pile!\n");
                            }
                        }
                        break;
                    case 'c':
                        deck.Cycle();
                        break;
                }
            }
        }

        private static void SetupPlayCards()
        {
            for (int i = 0; i < playArea.Length; i++)
            {
                playArea[i] = new PlaySet();

                for (int j = 0; j < i; j++)
                {
                    playArea[i].AddHiddenCard(deck.GetNextCard());
                }

                playArea[i].AddVisibleCard(deck.GetNextCard());
            }

            for (int i = 0; i < piles.Length; i++)
            {
                piles[i] = new Pile();
            }
        }

        private static bool CheckIfCanMoveToPile(int slot)
        {
            Card card;
            if (slot < 0)
            {
                card = deck.GetCurrentCard();
            }
            else
            {
                card = playArea[slot].GetTopCard();
            }

            foreach(Pile pile in piles)
            {
                if (pile.CanAddCard(card))
                {
                    playArea[slot].RemoveTopCard();
                    pile.AddCardToPile(card);
                    return true;
                }
            }

            return false;
        }

        private static bool CanMove(int set1, int set2)
        {
            Card card = null;
            if (set1 == -1)
            {
                card = deck.GetCurrentCard();
            }
            else
            {
                card = playArea[set1].GetBottomCard();
            }

            PlaySet destSet = playArea[set2];

            return CanMoveCardTo(destSet, card);
        }

        private static bool CanMoveCardTo(PlaySet destSet, Card card)
        {
            Card destCard = destSet.GetTopCard();

            if (destCard == null)
            {
                return card.Value == 13;
            }

            if (AreAlternateSuits(destCard, card))
            {
                return destCard.Value == (card.Value + 1);
            }

            return false;
        }

        private static bool AreAlternateSuits(Card c1, Card c2)
        {
            if (c1.Suit == Suit.Clubs || c1.Suit == Suit.Spades)
            {
                return c2.Suit == Suit.Hearts || c2.Suit == Suit.Diamonds;
            }
            else
            {
                return c2.Suit == Suit.Clubs || c2.Suit == Suit.Spades;
            }
        }

        private static void MoveCards(int set1, int set2)
        {
            List<Card> cards = playArea[set1].RemoveVisibleCards();
            playArea[set2].AddSetToVisibleCards(cards);
        }

        private static void MoveDeckCard(int set)
        {
            Card card = deck.PlayCurrentCard();
            playArea[set].AddVisibleCard(card);
        }

        private static void DisplayState()
        {
            int mostVisibleCards = 0;

            foreach(Pile pile in piles)
            {
                Card topCard = pile.GetTopCard();
                System.Console.Write((topCard != null ? GetVisibleCardString(topCard) : "X") + "  ");
            }

            System.Console.Write("\n\n");

            for (int i = 0; i < playArea.Length; i++)
            {
                System.Console.Write(i.ToString("D2") + "   ");
            }

            System.Console.Write("\n");

            foreach (PlaySet set in playArea)
            {
                System.Console.Write("Hi" + set.GetNumberOfHiddenCards() + "  ");

                if (set.GetNumberOfVisibleCards() > mostVisibleCards)
                {
                    mostVisibleCards = set.GetNumberOfVisibleCards();
                }
            }

            Card deckCard = deck.GetCurrentCard();
            System.Console.Write("    D: " + (deckCard != null ? GetVisibleCardString(deckCard) : "X") + "    G: " + deck.GetGraveyardCount());

            System.Console.Write("\n");

            for (int i = 0; i < mostVisibleCards; i++)
            {
                foreach (PlaySet set in playArea)
                {
                    List<Card> visibleCards = set.GetVisibleCards();

                    Card card = visibleCards.ElementAtOrDefault(i);

                    if (card != null)
                    {
                        System.Console.Write(GetVisibleCardString(card) + "  ");
                    }
                    else
                    {
                        System.Console.Write("     ");
                    }
                }

                System.Console.Write("\n");
            }

            System.Console.Write("\n\n");
        }

        private static string GetVisibleCardString(Card card)
        {
            string suit = string.Empty;

            switch (card.Suit)
            {
                case Suit.Clubs:
                    suit = "C";
                    break;
                case Suit.Spades:
                    suit = "S";
                    break;
                case Suit.Hearts:
                    suit = "H";
                    break;
                case Suit.Diamonds:
                    suit = "D";
                    break;
            }

            return suit + card.Value.ToString("D2");
        }

        private static bool HasWon()
        {
            foreach(PlaySet playSet in playArea)
            {
                if (playSet.GetNumberOfHiddenCards() > 0)
                {
                    return false;
                }
            }

            System.Console.WriteLine("You Win!\n\n");
            return true;
        }
    }
}
