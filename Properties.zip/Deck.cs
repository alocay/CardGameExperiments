﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitaireStat
{
    class Deck
    {
        private List<Card> cards = new List<Card>();
        private List<Card> graveyard = new List<Card>();
        private Card currentCard = null;
        private int cardsRetrieved = 0;

        public Deck()
        {
            for (int i = 0; i < 13; i++)
            {
                int index = i * 4;
                this.cards.Add(new Card((i + 1), Suit.Clubs));
                this.cards.Add(new Card((i + 1), Suit.Spades));
                this.cards.Add(new Card((i + 1), Suit.Hearts));
                this.cards.Add(new Card((i + 1), Suit.Diamonds));
            }

            this.Shuffle();
        }

        public int GetGraveyardCount()
        {
            return this.graveyard.Count;
        }

        public Card GetNextCard()
        {
            Card card = this.cards.First();

            if (card != null)
            {
                this.cards.RemoveAt(0);
            }

            return card;
        }

        public Card Cycle()
        {
            Card oldCard = this.currentCard;
            this.currentCard  = this.GetNextCard();

            if (oldCard != null)
            {
                this.graveyard.Add(oldCard);
            }
            
            if(this.currentCard == null)
            {
                this.MakeGraveyardActive();
            }

            return this.currentCard;
        }

        public Card GetCurrentCard()
        {
            return this.currentCard;
        }

        public Card PlayCurrentCard()
        {
            Card card = this.currentCard;
            this.cards.RemoveAt(0);
            this.currentCard = null;
            return card;
        }

        private void MakeGraveyardActive()
        {
            this.cards.Clear();
            this.cards.AddRange(this.graveyard);
            this.graveyard.Clear();
        }

        private void Shuffle()
        {
            Random r = new Random();
            //	Based on Java code from wikipedia:
            //	http://en.wikipedia.org/wiki/Fisher-Yates_shuffle

            for (int n = this.cards.Count - 1; n > 0; --n)
            {
                int k = r.Next(n + 1);
                Card temp = this.cards[n];
                this.cards[n] = cards[k];
                this.cards[k] = temp;
            }
        }
    }
}
